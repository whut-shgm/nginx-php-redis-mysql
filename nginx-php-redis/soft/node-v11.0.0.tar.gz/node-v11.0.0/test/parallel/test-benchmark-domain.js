'use strict';

require('../common');

const runBenchmark = require('../common/benchmark');

runBenchmark('domain', ['n=1', 'args=0']);
