macro DCHECK(x) = void(x);
macro DCHECK_EQ(a, b) = void(a, b);
macro DCHECK_GE(a, b) = void(a, b);
macro DCHECK_GT(a, b) = void(a, b);
macro DCHECK_LE(a, b) = void(a, b);
macro DCHECK_LT(a, b) = void(a, b);
macro DCHECK_NE(a, b) = void(a, b);
